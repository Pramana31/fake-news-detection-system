
import re
import json

import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

app = FastAPI(
    title="Fake News Detection API",
    description="Detects fake news using a soft-voting ensemble of ML models (LR, DT, GB, RF)",
    version="2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

FAKE_NEWS_DETECTION = "FAKE_NEWS_DETECTION"

# Load all models
lr            = joblib.load(f"{FAKE_NEWS_DETECTION}/lr_model.joblib")
dt            = joblib.load(f"{FAKE_NEWS_DETECTION}/dt_model.joblib")
gb            = joblib.load(f"{FAKE_NEWS_DETECTION}/gb_model.joblib")
rf            = joblib.load(f"{FAKE_NEWS_DETECTION}/rf_model.joblib")
vectorization = joblib.load(f"{FAKE_NEWS_DETECTION}/vectorizer.joblib")

models = {"LR": lr, "DT": dt, "GB": gb, "RF": rf}

# Ensemble members chosen in the notebook
with open(f"{FAKE_NEWS_DETECTION}/ensemble_config.json") as f:
    ENSEMBLE = json.load(f)["members"]

print("All models loaded successfully. Ensemble:", ENSEMBLE)


def wordopt(text: str) -> str:
    """Clean and normalize text."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"\[.*?\]", "", text)
    text = re.sub(r"https?://\S+|www\.\S+", "", text)
    text = re.sub(r"<.*?>+", "", text)
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\n", " ", text)
    text = re.sub(r"\w*\d\w*", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


label_map = {0: "FAKE", 1: "REAL"}


class NewsRequest(BaseModel):
    text: str


class PredictionResponse(BaseModel):
    input_text_preview: str
    model_votes: dict
    overall_verdict: str
    agreement: str
    confidence: str


@app.get("/", include_in_schema=False)
def home():
    return FileResponse("index.html")


@app.post("/predict", response_model=PredictionResponse)
def predict(payload: NewsRequest):
    cleaned = wordopt(payload.text)
    if not cleaned:
        raise HTTPException(status_code=400, detail="Text is empty after cleaning")

    xv = vectorization.transform([cleaned])

    # Individual model predictions (shown in the UI)
    preds = {name: label_map[int(m.predict(xv)[0])] for name, m in models.items()}

    # Soft vote: average predicted probabilities of the selected members
    avg = np.mean([models[n].predict_proba(xv)[0] for n in ENSEMBLE], axis=0)
    idx = int(avg.argmax())

    preview = payload.text[:100] + ("..." if len(payload.text) > 100 else "")

    return {
        "input_text_preview": preview,
        "model_votes": preds,
        "overall_verdict": label_map[idx],
        "agreement": "Ensemble: " + "+".join(ENSEMBLE),
        "confidence": f"{avg[idx] * 100:.0f}%"
    }


@app.get("/health")
def health():
    return {"status": "healthy", "models_loaded": len(models), "ensemble": ENSEMBLE}
