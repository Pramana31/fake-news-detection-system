
import os
import re
from collections import Counter

import joblib
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(
    title="Fake News Detection API",
    description="Detects fake news using ensemble of 4 ML models (LR, DT, GB, RF)",
    version="1.0"
)

FAKE_NEWS_DETECTION = "FAKE_NEWS_DETECTION"

# Load all models
lr            = joblib.load(f"{FAKE_NEWS_DETECTION}/lr_model.joblib")
dt            = joblib.load(f"{FAKE_NEWS_DETECTION}/dt_model.joblib")
gb            = joblib.load(f"{FAKE_NEWS_DETECTION}/gb_model.joblib")
rf            = joblib.load(f"{FAKE_NEWS_DETECTION}/rf_model.joblib")
vectorization = joblib.load(f"{FAKE_NEWS_DETECTION}/vectorizer.joblib")

print("✅ All models loaded successfully")


def wordopt(text: str) -> str:
    """Clean and normalize text."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"\[.*?\]", "", text)
    text = re.sub(r"https?://\S+|www\.\S+", "", text)
    text = re.sub(r"<.*?>+", "", text)
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\n", " ", text)
    text = re.sub(r"\w*\d\w*", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


label_map = {0: "FAKE", 1: "REAL"}


class NewsRequest(BaseModel):
    text: str


class PredictionResponse(BaseModel):
    input_text_preview: str
    model_votes: dict
    overall_verdict: str
    agreement: str
    confidence: str


@app.get("/")
def home():
    return {
        "message": "Fake News Detection API is running! ✅",
        "usage": "POST /predict with JSON body: {\"text\": \"your news article\"}",
        "models": ["Logistic Regression", "Decision Tree", "Gradient Boosting", "Random Forest"]
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(payload: NewsRequest):
    # Clean text
    cleaned = wordopt(payload.text)

    if not cleaned:
        return {
            "input_text_preview": "",
            "model_votes": {},
            "overall_verdict": "ERROR",
            "agreement": "0/4",
            "confidence": "0%"
        }

    # Vectorize
    xv = vectorization.transform([cleaned])

    # Get predictions from all 4 models
    preds = {
        "LR": label_map[int(lr.predict(xv)[0])],
        "DT": label_map[int(dt.predict(xv)[0])],
        "GB": label_map[int(gb.predict(xv)[0])],
        "RF": label_map[int(rf.predict(xv)[0])],
    }

    # Majority vote
    votes = list(preds.values())
    overall_verdict, count = Counter(votes).most_common(1)[0]

    return {
        "input_text_preview": payload.text[:100] + "...",
        "model_votes": preds,
        "overall_verdict": overall_verdict,
        "agreement": f"{count}/4 models agree",
        "confidence": f"{(count / 4) * 100:.0f}%"
    }


@app.get("/health")
def health():
    return {"status": "healthy", "models_loaded": 4}
